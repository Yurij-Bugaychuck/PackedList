#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QDebug>
#include<QtGui>
#include<QPainter>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    connect(timer, SIGNAL(timeout()), this, SLOT(processOneThing()));
}


MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{

    v = new PackedObjectContainer();


    for(int i = 0; i < ui->listWidget->count(); ++i){
        PackedListItem elem = dynamic_cast<PackedListItem*>(ui->listWidget->item(i));

        for(int j = 0; j < elem.Count; ++j){
            v->push_back(elem.polygon);
        }
    }
    qInfo() << "OK||" << v->size();


    if (v->size() == 0) return;



    Packed = new PackedLib(1000, 80);

//    Packed->progressBar = ui->progressBar;

    time = 0; stime = 0;
    timer->start(1000);
    QFuture<void> future = QtConcurrent::run([=]() {
        Packed->initPopulation(v, 50);
    });
    QFutureWatcher<void> *watcher = new QFutureWatcher<void>(this);
    connect(Packed, SIGNAL(setValue(int)), ui->progressBar, SLOT(setValue(int)));
    connect(watcher, SIGNAL(finished()), this, SLOT(handleFinished()));
    watcher->setFuture(future);

}

void MainWindow::handleFinished(){
    v = Packed->Top();
    qInfo() << v->size();
    timer->stop();
    //drawing
    QPixmap* image = new QPixmap(QSize(1000, 1000));
    QPaintEngine* eng = image->paintEngine();
    if(eng) {
        image->fill(Qt::white);
        //QPainter painter(ui->centralwidget);
        QPainter painterImage(image);
        //painter.setPen(QPen(Qt::black, 0.09));
        painterImage.setPen(QPen(Qt::black, 0.09));
        //    painter.;
        //painter.scale(2, 2);
        painterImage.scale(1, 1);

        for(int i = 0; i < v->size(); ++i){
           // painter.drawPolygon(v->at(i).polygon);
            painterImage.drawPolygon(v->at(i).polygon);
        }
        ui->label->setGeometry(0, 0, image->width(), image->height());
        ui->label->setPixmap(*image);

        image->save("fill.jpg");


    }

    delete v;
}
void MainWindow::processOneThing(){
    time+=1;
    qInfo() << time/60 << time % 60;
    QString t;
    if (time / 60 < 10) t += "0"; t += QString::number(time/60);
    t += ":";
    if (time % 60 < 10) t += "0"; t += QString::number(time%60);

    int pr = ui->progressBar->value();
    if (pr > 0 && stime == 0){
        double k = 100/pr;
        stime = k * time;
    }
    t += " / ";

    if (stime / 60 < 10) t += "0"; t += QString::number(stime/60);
    t += ":";
    if (stime % 60 < 10) t += "0"; t += QString::number(stime%60);

    ui->label_2->setText(t);

}
void MainWindow::on_pushButton_2_clicked()
{
    QDialog dialog(this);
    // Use a layout allowing to have a label next to each field
    QFormLayout form(&dialog);

    // Add some text above the fields
    form.addRow(new QLabel("The question ?"));

    // Add the lineEdits with their respective labels

    QLineEdit *Nameline = new QLineEdit(&dialog);
    form.addRow("Name", Nameline);

    QSpinBox *Widthline = new QSpinBox(&dialog);
    Widthline->setMaximum(500);
    form.addRow("Width", Widthline);

    QSpinBox *Heightline = new QSpinBox(&dialog);
    Heightline->setMaximum(500);
    form.addRow("Height", Heightline);

    QSpinBox *Countline = new QSpinBox(&dialog);
    Countline->setMaximum(100);
    form.addRow("Count", Countline);

    // Add some standard buttons (Cancel/Ok) at the bottom of the dialog
    QDialogButtonBox buttonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel,
                               Qt::Horizontal, &dialog);
    form.addRow(&buttonBox);
    QObject::connect(&buttonBox, SIGNAL(accepted()), &dialog, SLOT(accept()));
    QObject::connect(&buttonBox, SIGNAL(rejected()), &dialog, SLOT(reject()));





    // Show the dialog as modal
    if (dialog.exec() == QDialog::Accepted) {

        //--------------------
        PackedListItem *itm = new PackedListItem(Nameline->text(), Widthline->value(), Heightline->value(), Countline->value());

        addNewToList(itm);
    }
}


void MainWindow::addNewToList(PackedListItem* itm){
    QPixmap* image = new QPixmap(QSize(itm->Width, itm->Height));
    QPaintEngine* eng = image->paintEngine();
    if(eng) {
        image->fill(Qt::white);
        //QPainter painter(ui->centralwidget);
        QPainter painterImage(image);
        //painter.setPen(QPen(Qt::black, 0.09));
        painterImage.setPen(QPen(Qt::black, 0.09));
        //    painter.;
        //painter.scale(2, 2);
        painterImage.scale(1, 1);
        QPainterPath path;
        path.addPolygon(itm->polygon);

        QBrush brush;
            brush.setColor(Qt::black);
            brush.setStyle(Qt::SolidPattern);
        painterImage.fillPath(path, brush);
    }

    itm->setIcon(*image);
    itm->setSizeHint(QSize(itm->sizeHint().width(), 90));
    ui->listWidget->setIconSize(QSize(80, image->width()));
    ui->listWidget->addItem(itm);


    //---------------
    QHBoxLayout *HLay = new QHBoxLayout();
    QVBoxLayout *HLay2 = new QVBoxLayout();
    QVBoxLayout *VLay1 = new QVBoxLayout();
    VLay1->setAlignment(Qt::AlignRight);
    QPushButton *b1 = new QPushButton;
    QPixmap delBtnIcon(":/assets/stop.png");
    b1->setIcon(delBtnIcon);
    b1->setIconSize(QSize(20, 20));
    b1->setStyleSheet("background-color: transparent; background-position:center center;");
    b1->setFixedSize(QSize(20, 20));

    QPushButton *b2 = new QPushButton;
    QPixmap copyBtnIcon(":/assets/copy.png");
    b2->setIcon(copyBtnIcon);
    b2->setIconSize(QSize(20, 20));
    b2->setStyleSheet("background-color: transparent; background-position:center center;");
    b2->setFixedSize(QSize(20, 20));

    QLabel *n = new QLabel((itm->Name));
    n->setStyleSheet("background: url(':/assets/tag.png') no-repeat left center; padding-left: 20px; vertical-align:middle;");

    QLabel *w = new QLabel(QString::number(itm->Width));
    w->setStyleSheet("background: url(':/assets/width.png') no-repeat left center; padding-left: 20px; vertical-align:middle;");

    QLabel *h = new QLabel(QString::number(itm->Height));
    h->setStyleSheet("background: url(':/assets/height.png') no-repeat; background-position: left center; padding-left: 20px; vertical-align:middle;");
    QLabel *c= new QLabel("Count:" + QString::number(itm->Count));

    HLay2->addWidget(n);
    HLay2->addWidget(w);
    HLay2->addWidget(h);
    HLay2->addWidget(c);


    VLay1->addWidget(b1);
    VLay1->addWidget(b2);
    HLay->addLayout(HLay2);
    HLay->addLayout(VLay1);

    QWidget * twoButtonWidget = new QWidget();


    twoButtonWidget->setLayout( HLay );

    ui->listWidget->setItemWidget(itm, twoButtonWidget);

    connect(b1, SIGNAL(clicked()), this, SLOT(removeFromList()));
    connect(b2, SIGNAL(clicked()), this, SLOT(copyFromList()));
}

void MainWindow::removeFromList(){
    QPoint globalCursorPos = ui->listWidget->mapFromGlobal(QCursor::pos());
    qInfo() <<globalCursorPos<< ui->listWidget->itemAt(globalCursorPos);
    PackedListItem *it = dynamic_cast<PackedListItem*>(ui->listWidget->itemAt(globalCursorPos));

    qInfo() << it->Name;

    delete it;
}
void MainWindow::copyFromList(){
    QPoint globalCursorPos = ui->listWidget->mapFromGlobal(QCursor::pos());
    qInfo() <<globalCursorPos<< ui->listWidget->itemAt(globalCursorPos);
    PackedListItem *it = dynamic_cast<PackedListItem*>(ui->listWidget->itemAt(globalCursorPos));

    PackedListItem *newIt = new PackedListItem(it);
    addNewToList(newIt);

}
void MainWindow::setnovitem(QListWidgetItem* itm){
    qInfo() << "KEEEK";
    novitem = itm;
}
