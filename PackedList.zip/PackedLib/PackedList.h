#ifndef PACKEDLISTITEM_H
#define PACKEDLISTITEM_H
#include<QPixmap>
#include<PackedLib/PackedObject.h>
#include<QListWidget>
class PackedListItem : public QListWidgetItem
{
public:
    QPixmap *poly;
    QString Name = "Ok";
    int Width;
    int Height;
    int Count;
    QPolygon polygon;

    PackedListItem(){

    }
    PackedListItem(QString name, int w, int h, int count){
        Name = name;
        Width = w;
        Height = h;
        Count = count;
        polygon.putPoints(0, 4, 0, 0, 0, h, w, h, w, 0);
    }
    PackedListItem(PackedListItem* it){
        Name = it->Name;
        Width = it->Width;
        Height = it->Height;
        Count = it->Count;
        polygon = it->polygon;
    }
    PackedListItem& operator=(PackedListItem &it){
        Name = it.Name;
        Width = it.Width;
        Height = it.Height;
        Count = it.Count;
        polygon = it.polygon;

        return *this;
    }
};

#endif // PACKEDLISTITEM_H
