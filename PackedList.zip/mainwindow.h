#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include<PackedLib/PackedObject.h>
#include<QListWidget>
#include<PackedLib/PackedList.h>
#include<QDialog>
#include<QFormLayout>
#include<QLineEdit>
#include<QSpinBox>
#include<QDialogButtonBox>
#include<QMap>
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

    int time = 0;
    int stime = 0;
public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    PackedObjectContainer* v;
    PackedLib* Packed;
    QTimer *timer = new QTimer(this);
    void addNewToList(PackedListItem*);

    QListWidgetItem* novitem;
private slots:

    void processOneThing();
    void handleFinished();
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void removeFromList();

    void copyFromList();

    void setnovitem(QListWidgetItem* itm);
public slots:

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
